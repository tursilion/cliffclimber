This game was originally written in TI BASIC by Mike Brent (Ward) in 1987.

In 1993 it was updated by Lucie Dorais and Jeff Brown of the Ottawa TI User Group for Extended BASIC.

This game was compiled from TI BASIC/TI EXTENDED BASIC by TMOP in 2020.
- Oct 2020 by TMOP

Remember to visit the Italian TI99 site: http://www.ti99iuc.it/



